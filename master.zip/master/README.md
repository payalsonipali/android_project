# todo list in kotlin
todo list demo project created in kotlin using room database. and also added notification to notify user at specific date
